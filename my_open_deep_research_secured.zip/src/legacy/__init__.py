"""Planning, research, and report generation."""

__version__ = "0.0.15"